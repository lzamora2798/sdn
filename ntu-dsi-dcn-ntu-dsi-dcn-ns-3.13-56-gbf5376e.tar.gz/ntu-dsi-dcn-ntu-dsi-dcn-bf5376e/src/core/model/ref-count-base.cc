#include "ref-count-base.h"

namespace ns3 {

RefCountBase::~RefCountBase ()
{
}

} // namespace ns3
