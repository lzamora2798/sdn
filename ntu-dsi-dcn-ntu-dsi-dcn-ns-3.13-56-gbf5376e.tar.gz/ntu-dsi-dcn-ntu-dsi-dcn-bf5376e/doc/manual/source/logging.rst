.. include:: replace.txt

Logging
-------

*This chapter not yet written.  For now, the ns-3 tutorial contains logging
information.*
